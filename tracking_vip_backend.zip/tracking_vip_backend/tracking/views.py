from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import LocationLog
from .serializers import LocationLogSerializer
from rest_framework import generics

class LocationLogCreateView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = LocationLogSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LocationLogListView(generics.ListAPIView):
    serializer_class = LocationLogSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return LocationLog.objects.filter(user=self.request.user).order_by('-timestamp')
