from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class LocationLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    latitude = models.FloatField()
    longitude = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)
    photo = models.ImageField(upload_to='location_photos/', null=True, blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.latitude}, {self.longitude} @ {self.timestamp}"






#class LocationLog(models.Model):
#    user = models.ForeignKey(User, on_delete=models.CASCADE,
#    related_name='location_logs')
#    latitude = models.FloatField()
#    longitude = models.FloatField()
#    timestamp = models.DateTimeField(auto_now_add=True)

#    def __str__(self):
#        return f"{self.user.username} at {self.timestamp}"
