from django.contrib import admin
from .models import LocationLog

admin.site.register(LocationLog)
