from django.urls import path
from .views import LocationLogCreateView
from .views import LocationLogListView

urlpatterns = [
    path('log-location/', LocationLogCreateView.as_view(), name='log_location'),
    path('history/', LocationLogListView.as_view(), name='location_history'),
]
